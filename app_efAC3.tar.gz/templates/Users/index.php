<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\User> $users
 */
?>
<div class="users-index-container">
    <!-- Header Moderno con gradiente -->
    <div class="modern-header mb-4">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-md-7">
                    <div class="header-content">
                        <div class="header-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="header-text">
                            <h1 class="header-title mb-0"><?= __('Gestión de Usuarios') ?></h1>
                            <p class="header-subtitle mt-2 mb-0">
                                <i class="fas fa-chart-line me-1"></i> 
                                <?= $this->Paginator->counter('{{count}}') ?> usuarios registrados
                                <span class="separator">•</span>
                                <i class="fas fa-clock me-1"></i> 
                                Última actualización: <?= date('d/m/Y H:i') ?>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-5 text-md-end mt-3 mt-md-0">
                    <div class="header-actions">
                        <div class="theme-switch-wrapper me-3">
                            <i class="fas fa-sun theme-icon"></i>
                            <label class="theme-switch">
                                <input type="checkbox" id="theme-toggle">
                                <span class="slider round"></span>
                            </label>
                            <i class="fas fa-moon theme-icon"></i>
                        </div>
                        <?= $this->Html->link(
                            '<i class="fas fa-plus-circle me-2"></i> Nuevo Usuario',
                            ['action' => 'add'],
                            [
                                'class' => 'btn btn-primary-gradient',
                                'escape' => false
                            ]
                        ) ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid">
        <!-- Tarjeta de Estadísticas -->
        <div class="stats-cards mb-4">
            <div class="row g-3">
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="stat-icon bg-primary-light">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-info">
                            <h3 class="stat-number"><?= $this->Paginator->counter('{{count}}') ?></h3>
                            <p class="stat-label">Total Usuarios</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="stat-icon bg-success-light">
                            <i class="fas fa-user-check"></i>
                        </div>
                        <div class="stat-info">
                            <h3 class="stat-number"><?= $users->count() ?></h3>
                            <p class="stat-label">Usuarios Activos</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="stat-icon bg-info-light">
                            <i class="fas fa-language"></i>
                        </div>
                        <div class="stat-info">
                            <h3 class="stat-number">3</h3>
                            <p class="stat-label">Idiomas</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="stat-icon bg-warning-light">
                            <i class="fas fa-calendar-week"></i>
                        </div>
                        <div class="stat-info">
                            <h3 class="stat-number"><?= date('d/m') ?></h3>
                            <p class="stat-label">Este Mes</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

       

        <!-- Tabla de Usuarios -->
        <div class="users-table-card">
            <div class="card-header-custom">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <i class="fas fa-table me-2"></i>
                        <strong>Listado de Usuarios</strong>
                    </div>
                    <div class="table-info">
                        <i class="fas fa-info-circle me-1"></i>
                        Mostrando <?= $this->Paginator->counter('{{current}}') ?> de <?= $this->Paginator->counter('{{count}}') ?>
                    </div>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-modern">
                    <thead>
                        <tr>
                            <th class="sortable">
                                <?= $this->Paginator->sort('id', '#') ?>
                                <i class="fas fa-sort ms-1"></i>
                            </th>
                            <th class="sortable">
                                <?= $this->Paginator->sort('nombre', 'Nombre') ?>
                                <i class="fas fa-sort ms-1"></i>
                            </th>
                            <th class="sortable">
                                <?= $this->Paginator->sort('apellido', 'Apellido') ?>
                                <i class="fas fa-sort ms-1"></i>
                            </th>
                            <th class="sortable">
                                <?= $this->Paginator->sort('correo', 'Email') ?>
                                <i class="fas fa-sort ms-1"></i>
                            </th>
                            <th><?= $this->Paginator->sort('created', 'Fecha Registro') ?></th>
                            <th><?= $this->Paginator->sort('modified', 'Actualización') ?></th>
                            <th><?= $this->Paginator->sort('languaje', 'Idioma') ?></th>
                            <th class="text-center">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($users) > 0): ?>
                            <?php foreach ($users as $user): ?>
                                <tr class="user-row">
                                    <td class="user-id">#<?= $this->Number->format($user->id) ?></td>
                                    <td>
                                        <div class="user-info">
                                            <div class="user-avatar">
                                                <?= strtoupper(substr($user->nombre, 0, 1)) . strtoupper(substr($user->apellido, 0, 1)) ?>
                                            </div>
                                            <span class="user-name"><?= h($user->nombre) ?></span>
                                        </div>
                                    </td>
                                    <td><?= h($user->apellido) ?></td>
                                    <td>
                                        <a href="mailto:<?= h($user->correo) ?>" class="email-link">
                                            <i class="fas fa-envelope me-1"></i>
                                            <?= h($user->correo) ?>
                                        </a>
                                    </td>
                                    <td>
                                        <span class="date-badge">
                                            <i class="far fa-calendar-alt me-1"></i>
                                            <?= $user->created ? $user->created->format('d/m/Y H:i') : '—' ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($user->modified && $user->modified != $user->created): ?>
                                            <span class="date-badge">
                                                <i class="fas fa-sync-alt me-1"></i>
                                                <?= $user->modified->format('d/m/Y H:i') ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted">—</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
                                        $langBadges = [
                                            'es' => ['class' => 'badge-es', 'icon' => 'es', 'text' => 'Español'],
                                            'en' => ['class' => 'badge-en', 'icon' => 'gb', 'text' => 'English'],
                                            'pt' => ['class' => 'badge-pt', 'icon' => 'br', 'text' => 'Português']
                                        ];
                                        $lang = $user->languaje ?? 'es';
                                        $badge = $langBadges[$lang] ?? $langBadges['es'];
                                        ?>
                                        <span class="language-badge <?= $badge['class'] ?>">
                                            <span class="flag-icon flag-icon-<?= $badge['icon'] ?> me-1"></span>
                                            <?= $badge['text'] ?>
                                        </span>
                                    </td>
                                    <td class="actions-cell">
                                        <div class="action-buttons">
                                            <?= $this->Html->link(
                                                '<i class="fas fa-eye"></i>',
                                                ['action' => 'view', $user->id],
                                                [
                                                    'class' => 'action-btn btn-view',
                                                    'escape' => false,
                                                    'title' => 'Ver detalles'
                                                ]
                                            ) ?>
                                            <?= $this->Html->link(
                                                '<i class="fas fa-edit"></i>',
                                                ['action' => 'edit', $user->id],
                                                [
                                                    'class' => 'action-btn btn-edit',
                                                    'escape' => false,
                                                    'title' => 'Editar usuario'
                                                ]
                                            ) ?>
                                            <?= $this->Form->postLink(
                                                '<i class="fas fa-trash-alt"></i>',
                                                ['action' => 'delete', $user->id],
                                                [
                                                    'method' => 'delete',
                                                    'confirm' => __('¿Estás seguro de eliminar al usuario "{0} {1}"?', $user->nombre, $user->apellido),
                                                    'class' => 'action-btn btn-delete',
                                                    'escape' => false,
                                                    'title' => 'Eliminar usuario'
                                                ]
                                            ) ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" class="text-center py-5">
                                    <div class="empty-state">
                                        <i class="fas fa-users-slash fa-4x text-muted mb-3"></i>
                                        <h5 class="text-muted">No hay usuarios registrados</h5>
                                        <p class="text-muted">Comienza agregando un nuevo usuario</p>
                                        <?= $this->Html->link(
                                            '<i class="fas fa-plus-circle me-1"></i> Crear primer usuario',
                                            ['action' => 'add'],
                                            ['class' => 'btn btn-primary mt-2', 'escape' => false]
                                        ) ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Paginación Mejorada -->
        <div class="pagination-wrapper mt-4">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="pagination-info">
                        <i class="fas fa-chart-line me-2"></i>
                        <?= $this->Paginator->counter(
                            __('Mostrando <strong>{{current}}</strong> de <strong>{{count}}</strong> usuarios · Página <strong>{{page}}</strong> de <strong>{{pages}}</strong>')
                        ) ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <ul class="pagination-custom">
                        <?= $this->Paginator->first('<<', ['class' => 'page-link-custom', 'escape' => false]) ?>
                        <?= $this->Paginator->prev('<', ['class' => 'page-link-custom', 'escape' => false]) ?>
                        <?= $this->Paginator->numbers([
                            'class' => 'page-link-custom',
                            'currentClass' => 'active',
                            'modulus' => 3
                        ]) ?>
                        <?= $this->Paginator->next('>', ['class' => 'page-link-custom', 'escape' => false]) ?>
                        <?= $this->Paginator->last('>>', ['class' => 'page-link-custom', 'escape' => false]) ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Font Awesome y Flags -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.5.0/css/flag-icon.min.css" />

<style>
    /* Variables para modo claro */
    :root {
        --bg-primary: #f5f7fb;
        --bg-secondary: #ffffff;
        --text-primary: #2d3748;
        --text-secondary: #718096;
        --border-color: #e2e8f0;
        --card-bg: #ffffff;
        --header-bg: #f8f9fa;
        --shadow-sm: 0 1px 3px rgba(0,0,0,0.1);
        --shadow-md: 0 4px 6px rgba(0,0,0,0.07);
        --shadow-lg: 0 10px 25px rgba(0,0,0,0.1);
        --primary-color: #4361ee;
        --success-color: #28a745;
        --danger-color: #dc3545;
        --warning-color: #ffc107;
        --info-color: #17a2b8;
        --gradient-primary: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }

    /* Variables para modo noche */
    body.dark-mode {
        --bg-primary: #1a1a2e;
        --bg-secondary: #16213e;
        --text-primary: #e0e0e0;
        --text-secondary: #a0a0a0;
        --border-color: #2d2d44;
        --card-bg: #0f0f1a;
        --header-bg: #0a0a14;
        --shadow-sm: 0 1px 3px rgba(0,0,0,0.3);
        --shadow-md: 0 4px 6px rgba(0,0,0,0.3);
        --shadow-lg: 0 10px 25px rgba(0,0,0,0.3);
        --primary-color: #5a7d9a;
    }

    /* Estilos generales */
    body {
        background-color: var(--bg-primary);
        color: var(--text-primary);
        transition: all 0.3s ease;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    }

    .users-index-container {
        max-width: 1400px;
        margin: 0 auto;
        padding: 20px;
    }

    /* Header Moderno */
    .modern-header {
        background: var(--gradient-primary);
        color: white;
        padding: 2rem 0;
        margin: -1.5rem -1rem 2rem -1rem;
        box-shadow: var(--shadow-lg);
        border-radius: 0 0 20px 20px;
    }

    .header-content {
        display: flex;
        align-items: center;
        gap: 1.5rem;
    }

    .header-icon {
        width: 60px;
        height: 60px;
        background: rgba(255,255,255,0.2);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 28px;
        backdrop-filter: blur(10px);
    }

    .header-title {
        font-size: 2rem;
        font-weight: 700;
        letter-spacing: -0.5px;
        margin: 0;
    }

    .header-subtitle {
        font-size: 0.9rem;
        opacity: 0.95;
        margin: 0;
    }

    .separator {
        margin: 0 8px;
    }

    /* Tarjetas de Estadísticas */
    .stats-cards {
        margin-bottom: 1.5rem;
    }

    .stat-card {
        background: var(--card-bg);
        border-radius: 12px;
        padding: 1.25rem;
        display: flex;
        align-items: center;
        gap: 1rem;
        box-shadow: var(--shadow-sm);
        transition: all 0.3s ease;
        border: 1px solid var(--border-color);
    }

    .stat-card:hover {
        transform: translateY(-3px);
        box-shadow: var(--shadow-md);
    }

    .stat-icon {
        width: 50px;
        height: 50px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
    }

    .bg-primary-light {
        background: linear-gradient(135deg, #667eea20 0%, #764ba220 100%);
        color: #667eea;
    }

    .bg-success-light {
        background: rgba(40, 167, 69, 0.1);
        color: #28a745;
    }

    .bg-info-light {
        background: rgba(23, 162, 184, 0.1);
        color: #17a2b8;
    }

    .bg-warning-light {
        background: rgba(255, 193, 7, 0.1);
        color: #ffc107;
    }

    .stat-number {
        font-size: 1.5rem;
        font-weight: 700;
        margin: 0;
        color: var(--text-primary);
    }

    .stat-label {
        margin: 0;
        color: var(--text-secondary);
        font-size: 0.85rem;
    }

    /* Barra de Búsqueda */
    .search-filters-card {
        background: var(--card-bg);
        border-radius: 12px;
        padding: 1.25rem;
        box-shadow: var(--shadow-sm);
        border: 1px solid var(--border-color);
    }

    /* Tabla de Usuarios */
    .users-table-card {
        background: var(--card-bg);
        border-radius: 12px;
        overflow: hidden;
        box-shadow: var(--shadow-sm);
        border: 1px solid var(--border-color);
    }

    .card-header-custom {
        padding: 1rem 1.5rem;
        background: var(--header-bg);
        border-bottom: 1px solid var(--border-color);
    }

    .table-modern {
        margin-bottom: 0;
    }

    .table-modern thead th {
        background: var(--header-bg);
        padding: 1rem;
        font-weight: 600;
        font-size: 0.85rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: var(--text-secondary);
        border-bottom: 2px solid var(--border-color);
    }

    .sortable {
        cursor: pointer;
    }

    .sortable i {
        opacity: 0.5;
        font-size: 0.7rem;
    }

    .user-row {
        transition: all 0.2s ease;
    }

    .user-row:hover {
        background: var(--header-bg);
        transform: translateX(5px);
    }

    .user-id {
        font-weight: 700;
        color: var(--primary-color);
    }

    .user-info {
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .user-avatar {
        width: 36px;
        height: 36px;
        background: var(--gradient-primary);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: 600;
        font-size: 14px;
    }

    .user-name {
        font-weight: 500;
    }

    .email-link {
        color: var(--text-primary);
        text-decoration: none;
        transition: color 0.2s;
    }

    .email-link:hover {
        color: var(--primary-color);
    }

    .date-badge {
        font-size: 0.85rem;
        color: var(--text-secondary);
    }

    .language-badge {
        display: inline-flex;
        align-items: center;
        padding: 0.25rem 0.75rem;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 500;
    }

    .badge-es {
        background: #fee2e2;
        color: #c53030;
    }

    .badge-en {
        background: #e2f0ff;
        color: #2c5282;
    }

    .badge-pt {
        background: #e6f7e6;
        color: #276749;
    }

    body.dark-mode .badge-es {
        background: #4a1a1a;
        color: #ffaaaa;
    }

    body.dark-mode .badge-en {
        background: #1a2a4a;
        color: #aaccff;
    }

    body.dark-mode .badge-pt {
        background: #1a3a1a;
        color: #aaffaa;
    }

    /* Botones de Acción */
    .actions-cell {
        text-align: center;
    }

    .action-buttons {
        display: flex;
        gap: 0.5rem;
        justify-content: center;
    }

    .action-btn {
        width: 32px;
        height: 32px;
        border-radius: 8px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: all 0.2s ease;
        text-decoration: none;
    }

    .btn-view {
        background: rgba(23, 162, 184, 0.1);
        color: #17a2b8;
    }

    .btn-edit {
        background: rgba(255, 193, 7, 0.1);
        color: #ffc107;
    }

    .btn-delete {
        background: rgba(220, 53, 69, 0.1);
        color: #dc3545;
    }

    .action-btn:hover {
        transform: translateY(-2px);
        text-decoration: none;
    }

    .btn-view:hover {
        background: #17a2b8;
        color: white;
    }

    .btn-edit:hover {
        background: #ffc107;
        color: #856404;
    }

    .btn-delete:hover {
        background: #dc3545;
        color: white;
    }

    /* Switch modo noche */
    .theme-switch-wrapper {
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }

    .theme-icon {
        font-size: 14px;
        color: white;
    }

    .theme-switch {
        position: relative;
        display: inline-block;
        width: 50px;
        height: 24px;
    }

    .theme-switch input {
        opacity: 0;
        width: 0;
        height: 0;
    }

    .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: 0.4s;
        border-radius: 34px;
    }

    .slider:before {
        position: absolute;
        content: "";
        height: 18px;
        width: 18px;
        left: 3px;
        bottom: 3px;
        background-color: white;
        transition: 0.4s;
        border-radius: 50%;
    }

    input:checked + .slider {
        background-color: #2196f3;
    }

    input:checked + .slider:before {
        transform: translateX(26px);
    }

    /* Botones */
    .btn-primary-gradient {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        padding: 0.6rem 1.5rem;
        border-radius: 8px;
        font-weight: 500;
        transition: all 0.3s;
        display: inline-flex;
        align-items: center;
        text-decoration: none;
    }

    .btn-primary-gradient:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        color: white;
    }

    .btn-primary {
        background: var(--primary-color);
        color: white;
        border: none;
        padding: 0.5rem 1rem;
        border-radius: 6px;
        transition: all 0.2s;
    }

    .btn-primary:hover {
        transform: translateY(-1px);
    }

    .btn-outline-secondary {
        background: transparent;
        border: 1px solid var(--border-color);
        color: var(--text-secondary);
        padding: 0.5rem 1rem;
        border-radius: 6px;
        transition: all 0.2s;
    }

    .btn-outline-secondary:hover {
        background: var(--border-color);
        color: var(--text-primary);
    }

    /* Paginación */
    .pagination-wrapper {
        background: var(--card-bg);
        padding: 1rem;
        border-radius: 12px;
        box-shadow: var(--shadow-sm);
        border: 1px solid var(--border-color);
    }

    .pagination-custom {
        display: flex;
        justify-content: flex-end;
        gap: 0.5rem;
        margin: 0;
        list-style: none;
    }

    .page-link-custom {
        padding: 0.5rem 0.75rem;
        border-radius: 8px;
        color: var(--primary-color);
        text-decoration: none;
        transition: all 0.2s;
        display: inline-block;
    }

    .page-link-custom:hover {
        background: var(--primary-color);
        color: white;
    }

    .pagination-custom .active .page-link-custom {
        background: var(--gradient-primary);
        color: white;
    }

    .pagination-info {
        font-size: 0.9rem;
        color: var(--text-secondary);
    }

    /* Empty State */
    .empty-state {
        text-align: center;
        padding: 3rem;
    }

    /* Form controls */
    .form-control, .form-select {
        background: var(--card-bg);
        border: 1px solid var(--border-color);
        color: var(--text-primary);
        padding: 0.5rem 0.75rem;
        border-radius: 8px;
        transition: all 0.2s;
    }

    .form-control:focus, .form-select:focus {
        outline: none;
        border-color: var(--primary-color);
        box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.1);
    }

    .input-group-text {
        background: var(--card-bg);
        border: 1px solid var(--border-color);
        color: var(--text-secondary);
    }

    /* Responsive */
    @media (max-width: 768px) {
        .users-index-container {
            padding: 10px;
        }

        .modern-header {
            margin: -1rem -0.5rem 1rem -0.5rem;
        }

        .header-content {
            flex-direction: column;
            text-align: center;
        }

        .stat-card {
            margin-bottom: 1rem;
        }

        .pagination-custom {
            justify-content: center;
            margin-top: 1rem;
        }

        .pagination-info {
            text-align: center;
        }

        .action-buttons {
            flex-direction: column;
            gap: 0.25rem;
        }

        .action-btn {
            width: 100%;
        }

        .header-actions {
            display: flex;
            justify-content: center;
            align-items: center;
        }
    }
</style>

<script>
    // Modo noche con localStorage
    document.addEventListener('DOMContentLoaded', function() {
        const toggleSwitch = document.getElementById('theme-toggle');
        
        // Verificar preferencia guardada
        const currentTheme = localStorage.getItem('theme');
        
        if (currentTheme) {
            document.body.classList.add(currentTheme);
            if (currentTheme === 'dark-mode') {
                toggleSwitch.checked = true;
            }
        }
        
        // Escuchar cambio de tema
        toggleSwitch.addEventListener('change', function(e) {
            if (e.target.checked) {
                document.body.classList.add('dark-mode');
                localStorage.setItem('theme', 'dark-mode');
            } else {
                document.body.classList.remove('dark-mode');
                localStorage.setItem('theme', 'light-mode');
            }
        });
    });
</script>
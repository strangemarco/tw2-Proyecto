<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\User $user
 */
?>
<div class="view-container">
    <!-- Botón de modo noche -->
    <div class="theme-switch-wrapper">
        <i class="fas fa-sun theme-icon"></i>
        <label class="theme-switch">
            <input type="checkbox" id="theme-toggle">
            <span class="slider round"></span>
        </label>
        <i class="fas fa-moon theme-icon"></i>
    </div>

    <div class="row">
        <aside class="column">
            <div class="side-nav">
                <h4 class="heading"><?= __('Actions') ?></h4>
                <div class="action-buttons">
                    <?= $this->Html->link(
                        '<i class="fas fa-edit"></i> ' . __('Edit User'),
                        ['action' => 'edit', $user->id],
                        ['class' => 'side-nav-item edit-btn', 'escape' => false]
                    ) ?>
                    <?= $this->Form->postLink(
                        '<i class="fas fa-trash-alt"></i> ' . __('Delete User'),
                        ['action' => 'delete', $user->id],
                        [
                            'confirm' => __('Are you sure you want to delete # {0}?', $user->id),
                            'class' => 'side-nav-item delete-btn',
                            'escape' => false
                        ]
                    ) ?>
                    <?= $this->Html->link(
                        '<i class="fas fa-list"></i> ' . __('List Users'),
                        ['action' => 'index'],
                        ['class' => 'side-nav-item list-btn', 'escape' => false]
                    ) ?>
                    <?= $this->Html->link(
                        '<i class="fas fa-plus"></i> ' . __('New User'),
                        ['action' => 'add'],
                        ['class' => 'side-nav-item add-btn', 'escape' => false]
                    ) ?>
                </div>
            </div>
        </aside>
        <div class="column column-80">
            <div class="users view content">
                <div class="view-header">
                    <div class="user-avatar-large">
                        <?= strtoupper(substr($user->nombre, 0, 1)) . strtoupper(substr($user->apellido, 0, 1)) ?>
                    </div>
                    <div class="user-title">
                        <h3><?= h($user->nombre) . ' ' . h($user->apellido) ?></h3>
                        <p class="user-email">
                            <i class="fas fa-envelope"></i> <?= h($user->correo) ?>
                        </p>
                    </div>
                </div>

                <div class="info-card">
                    <div class="info-section">
                        <h4 class="info-title">
                            <i class="fas fa-user-circle"></i> Información Personal
                        </h4>
                        <div class="info-grid">
                            <div class="info-item">
                                <div class="info-label">
                                    <i class="fas fa-user"></i> <?= __('Nombre') ?>
                                </div>
                                <div class="info-value"><?= h($user->nombre) ?></div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">
                                    <i class="fas fa-user-tag"></i> <?= __('Apellido') ?>
                                </div>
                                <div class="info-value"><?= h($user->apellido) ?></div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">
                                    <i class="fas fa-envelope"></i> <?= __('Correo Electrónico') ?>
                                </div>
                                <div class="info-value">
                                    <a href="mailto:<?= h($user->correo) ?>" class="email-link">
                                        <?= h($user->correo) ?>
                                    </a>
                                </div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">
                                    <i class="fas fa-language"></i> <?= __('Idioma') ?>
                                </div>
                                <div class="info-value">
                                    <?php
                                    $langBadges = [
                                        'es' => ['class' => 'badge-es', 'text' => 'Español'],
                                        'en' => ['class' => 'badge-en', 'text' => 'English'],
                                        'pt' => ['class' => 'badge-pt', 'text' => 'Português']
                                    ];
                                    $lang = $user->languaje ?? 'es';
                                    $badge = $langBadges[$lang] ?? $langBadges['es'];
                                    ?>
                                    <span class="language-badge <?= $badge['class'] ?>">
                                        <?= $badge['text'] ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="info-section">
                        <h4 class="info-title">
                            <i class="fas fa-info-circle"></i> Información del Sistema
                        </h4>
                        <div class="info-grid">
                            <div class="info-item">
                                <div class="info-label">
                                    <i class="fas fa-hashtag"></i> <?= __('ID') ?>
                                </div>
                                <div class="info-value">
                                    <span class="id-badge">#<?= $this->Number->format($user->id) ?></span>
                                </div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">
                                    <i class="far fa-calendar-alt"></i> <?= __('Fecha de Creación') ?>
                                </div>
                                <div class="info-value">
                                    <i class="far fa-clock me-1"></i>
                                    <?= $user->created ? $user->created->format('d/m/Y H:i:s') : '—' ?>
                                </div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">
                                    <i class="fas fa-sync-alt"></i> <?= __('Última Actualización') ?>
                                </div>
                                <div class="info-value">
                                    <i class="far fa-clock me-1"></i>
                                    <?= $user->modified ? $user->modified->format('d/m/Y H:i:s') : '—' ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="action-footer">
                    <?= $this->Html->link(
                        '<i class="fas fa-arrow-left"></i> ' . __('Volver a la lista'),
                        ['action' => 'index'],
                        ['class' => 'btn btn-secondary', 'escape' => false]
                    ) ?>
                    <?= $this->Html->link(
                        '<i class="fas fa-edit"></i> ' . __('Editar Usuario'),
                        ['action' => 'edit', $user->id],
                        ['class' => 'btn btn-primary', 'escape' => false]
                    ) ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />

<style>
    /* Variables para modo claro (default) */
    :root {
        --bg-primary: #ffffff;
        --bg-secondary: #f8f9fa;
        --text-primary: #2d3748;
        --text-secondary: #718096;
        --border-color: #e2e8f0;
        --card-bg: #ffffff;
        --sidebar-bg: #f8f9fa;
        --shadow: 0 1px 3px rgba(0,0,0,0.1);
        --shadow-lg: 0 10px 25px rgba(0,0,0,0.1);
        --primary-color: #4361ee;
        --success-color: #28a745;
        --danger-color: #dc3545;
        --warning-color: #ffc107;
    }

    /* Variables para modo noche */
    body.dark-mode {
        --bg-primary: #1a1a2e;
        --bg-secondary: #16213e;
        --text-primary: #e0e0e0;
        --text-secondary: #a0a0a0;
        --border-color: #2d2d44;
        --card-bg: #0f0f1a;
        --sidebar-bg: #0a0a14;
        --shadow: 0 1px 3px rgba(0,0,0,0.3);
        --shadow-lg: 0 10px 25px rgba(0,0,0,0.3);
        --primary-color: #5a7d9a;
    }

    /* Estilos generales */
    body {
        background-color: var(--bg-primary);
        color: var(--text-primary);
        transition: all 0.3s ease;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    }

    .view-container {
        max-width: 1400px;
        margin: 0 auto;
        padding: 20px;
        position: relative;
    }

    /* Switch modo noche */
    .theme-switch-wrapper {
        position: fixed;
        top: 20px;
        right: 20px;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        background: var(--card-bg);
        padding: 8px 12px;
        border-radius: 30px;
        box-shadow: var(--shadow);
        z-index: 1000;
    }

    .theme-icon {
        font-size: 14px;
        color: var(--text-secondary);
    }

    .theme-switch {
        position: relative;
        display: inline-block;
        width: 50px;
        height: 24px;
    }

    .theme-switch input {
        opacity: 0;
        width: 0;
        height: 0;
    }

    .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: 0.4s;
        border-radius: 34px;
    }

    .slider:before {
        position: absolute;
        content: "";
        height: 18px;
        width: 18px;
        left: 3px;
        bottom: 3px;
        background-color: white;
        transition: 0.4s;
        border-radius: 50%;
    }

    input:checked + .slider {
        background-color: #2196f3;
    }

    input:checked + .slider:before {
        transform: translateX(26px);
    }

    /* Sidebar */
    .side-nav {
        background: var(--sidebar-bg);
        border-radius: 12px;
        padding: 20px;
        box-shadow: var(--shadow);
        border: 1px solid var(--border-color);
    }

    .heading {
        color: var(--text-primary);
        font-size: 1.1rem;
        font-weight: 600;
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 2px solid var(--primary-color);
    }

    .action-buttons {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .side-nav-item {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 10px 15px;
        border-radius: 8px;
        color: var(--text-primary);
        text-decoration: none;
        transition: all 0.2s ease;
        background: var(--card-bg);
    }

    .side-nav-item:hover {
        transform: translateX(5px);
        text-decoration: none;
    }

    .edit-btn:hover {
        background: var(--warning-color);
        color: #856404;
    }

    .delete-btn:hover {
        background: var(--danger-color);
        color: white;
    }

    .list-btn:hover {
        background: var(--primary-color);
        color: white;
    }

    .add-btn:hover {
        background: var(--success-color);
        color: white;
    }

    /* Contenido principal */
    .users.view.content {
        background: var(--card-bg);
        border-radius: 12px;
        padding: 30px;
        box-shadow: var(--shadow-lg);
        border: 1px solid var(--border-color);
    }

    .view-header {
        display: flex;
        align-items: center;
        gap: 20px;
        margin-bottom: 30px;
        padding-bottom: 20px;
        border-bottom: 2px solid var(--border-color);
    }

    .user-avatar-large {
        width: 80px;
        height: 80px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 32px;
        font-weight: 600;
        box-shadow: var(--shadow);
    }

    .user-title h3 {
        font-size: 28px;
        font-weight: 600;
        margin: 0;
        color: var(--text-primary);
    }

    .user-email {
        margin: 5px 0 0;
        color: var(--text-secondary);
        font-size: 14px;
    }

    .user-email i {
        margin-right: 5px;
    }

    /* Info Cards */
    .info-card {
        margin-bottom: 30px;
    }

    .info-section {
        margin-bottom: 25px;
        background: var(--bg-secondary);
        border-radius: 10px;
        padding: 20px;
        border: 1px solid var(--border-color);
    }

    .info-title {
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 20px;
        color: var(--primary-color);
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .info-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 20px;
    }

    .info-item {
        display: flex;
        flex-direction: column;
        gap: 8px;
    }

    .info-label {
        font-size: 12px;
        text-transform: uppercase;
        font-weight: 600;
        color: var(--text-secondary);
        letter-spacing: 0.5px;
        display: flex;
        align-items: center;
        gap: 6px;
    }

    .info-value {
        font-size: 16px;
        font-weight: 500;
        color: var(--text-primary);
    }

    .email-link {
        color: var(--primary-color);
        text-decoration: none;
        transition: color 0.2s;
    }

    .email-link:hover {
        text-decoration: underline;
    }

    .language-badge {
        display: inline-block;
        padding: 5px 12px;
        border-radius: 20px;
        font-size: 13px;
        font-weight: 500;
    }

    .badge-es {
        background: #fee2e2;
        color: #c53030;
    }

    .badge-en {
        background: #e2f0ff;
        color: #2c5282;
    }

    .badge-pt {
        background: #e6f7e6;
        color: #276749;
    }

    .id-badge {
        display: inline-block;
        padding: 4px 12px;
        background: var(--primary-color);
        color: white;
        border-radius: 6px;
        font-family: monospace;
        font-size: 14px;
    }

    /* Footer Actions */
    .action-footer {
        display: flex;
        gap: 15px;
        justify-content: flex-end;
        padding-top: 20px;
        border-top: 1px solid var(--border-color);
    }

    .btn {
        padding: 10px 20px;
        border-radius: 8px;
        text-decoration: none;
        transition: all 0.2s ease;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        font-weight: 500;
    }

    .btn-primary {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
    }

    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        color: white;
    }

    .btn-secondary {
        background: var(--bg-secondary);
        color: var(--text-primary);
        border: 1px solid var(--border-color);
    }

    .btn-secondary:hover {
        background: var(--border-color);
        transform: translateY(-2px);
    }

    /* Responsive */
    @media (max-width: 768px) {
        .view-container {
            padding: 10px;
        }

        .theme-switch-wrapper {
            position: relative;
            top: 0;
            right: 0;
            justify-content: flex-end;
            margin-bottom: 20px;
        }

        .row {
            flex-direction: column;
        }

        .column {
            width: 100% !important;
        }

        .view-header {
            flex-direction: column;
            text-align: center;
        }

        .info-grid {
            grid-template-columns: 1fr;
        }

        .action-footer {
            flex-direction: column;
        }

        .btn {
            justify-content: center;
        }
    }

    /* Animaciones */
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .users.view.content {
        animation: fadeIn 0.5s ease;
    }
</style>

<script>
    // Modo noche con localStorage
    document.addEventListener('DOMContentLoaded', function() {
        const toggleSwitch = document.getElementById('theme-toggle');
        
        // Verificar preferencia guardada
        const currentTheme = localStorage.getItem('theme');
        
        if (currentTheme) {
            document.body.classList.add(currentTheme);
            if (currentTheme === 'dark-mode') {
                toggleSwitch.checked = true;
            }
        }
        
        // Escuchar cambio de tema
        toggleSwitch.addEventListener('change', function(e) {
            if (e.target.checked) {
                document.body.classList.add('dark-mode');
                localStorage.setItem('theme', 'dark-mode');
            } else {
                document.body.classList.remove('dark-mode');
                localStorage.setItem('theme', 'light-mode');
            }
        });
    });
</script>
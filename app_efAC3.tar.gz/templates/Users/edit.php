<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\User $user
 */
?>
<div class="form-container">
    <!-- Botón de modo noche -->
    <div class="theme-switch-wrapper">
        <i class="fas fa-sun theme-icon"></i>
        <label class="theme-switch">
            <input type="checkbox" id="theme-toggle">
            <span class="slider round"></span>
        </label>
        <i class="fas fa-moon theme-icon"></i>
    </div>

    <div class="row">
        <aside class="column">
            <div class="side-nav">
                <h4 class="heading">
                    <i class="fas fa-bolt"></i> <?= __('Acciones Rápidas') ?>
                </h4>
                <div class="action-buttons">
                    <?= $this->Form->postLink(
                        '<i class="fas fa-trash-alt"></i> ' . __('Eliminar Usuario'),
                        ['action' => 'delete', $user->id],
                        [
                            'confirm' => __('¿Estás seguro de eliminar al usuario "{0} {1}"?', $user->nombre, $user->apellido),
                            'class' => 'side-nav-item delete-btn',
                            'escape' => false
                        ]
                    ) ?>
                    <?= $this->Html->link(
                        '<i class="fas fa-list"></i> ' . __('Listar Usuarios'),
                        ['action' => 'index'],
                        ['class' => 'side-nav-item list-btn', 'escape' => false]
                    ) ?>
                    <?= $this->Html->link(
                        '<i class="fas fa-eye"></i> ' . __('Ver Detalles'),
                        ['action' => 'view', $user->id],
                        ['class' => 'side-nav-item view-btn', 'escape' => false]
                    ) ?>
                </div>
            </div>
        </aside>
        <div class="column column-80">
            <div class="users form content">
                <div class="form-header">
                    <div class="form-icon">
                        <i class="fas fa-user-edit"></i>
                    </div>
                    <div class="form-title-section">
                        <h3><?= __('Editar Usuario') ?></h3>
                        <p class="form-subtitle">
                            <i class="fas fa-info-circle"></i> 
                            Modificando información de <strong><?= h($user->nombre) . ' ' . h($user->apellido) ?></strong>
                        </p>
                    </div>
                </div>

                <?= $this->Form->create($user, ['class' => 'modern-form']) ?>
                <fieldset>
                    <div class="form-section">
                        <h4 class="section-title">
                            <i class="fas fa-user-circle"></i> Información Personal
                        </h4>
                        <div class="form-grid">
                            <div class="form-group">
                                <?= $this->Form->control('nombre', [
                                    'label' => [
                                        'text' => '<i class="fas fa-user"></i> Nombre',
                                        'escape' => false
                                    ],
                                    'placeholder' => 'Ingrese el nombre',
                                    'class' => 'form-control',
                                    'required' => true,
                                    'value' => $user->nombre
                                ]) ?>
                            </div>
                            <div class="form-group">
                                <?= $this->Form->control('apellido', [
                                    'label' => [
                                        'text' => '<i class="fas fa-user-tag"></i> Apellido',
                                        'escape' => false
                                    ],
                                    'placeholder' => 'Ingrese el apellido',
                                    'class' => 'form-control',
                                    'required' => true,
                                    'value' => $user->apellido
                                ]) ?>
                            </div>
                        </div>
                    </div>

                    <div class="form-section">
                        <h4 class="section-title">
                            <i class="fas fa-envelope"></i> Información de Contacto
                        </h4>
                        <div class="form-group">
                            <?= $this->Form->control('correo', [
                                'label' => [
                                    'text' => '<i class="fas fa-envelope"></i> Correo Electrónico',
                                    'escape' => false
                                ],
                                'placeholder' => 'usuario@ejemplo.com',
                                'class' => 'form-control',
                                'type' => 'email',
                                'required' => true,
                                'value' => $user->correo
                            ]) ?>
                            <small class="form-text text-muted">
                                <i class="fas fa-info-circle"></i> El correo será usado para iniciar sesión
                            </small>
                        </div>
                    </div>

                    <div class="form-section">
                        <h4 class="section-title">
                            <i class="fas fa-lock"></i> Seguridad
                        </h4>
                        <div class="form-group">
                            <?= $this->Form->control('password', [
                                'label' => [
                                    'text' => '<i class="fas fa-key"></i> Contraseña',
                                    'escape' => false
                                ],
                                'placeholder' => 'Dejar en blanco para mantener la actual',
                                'class' => 'form-control',
                                'type' => 'password',
                                'required' => false
                            ]) ?>
                            <div class="password-strength" id="password-strength">
                                <div class="strength-bar"></div>
                                <span class="strength-text"></span>
                            </div>
                            <small class="form-text text-muted">
                                <i class="fas fa-shield-alt"></i> Mínimo 6 caracteres. Dejar en blanco para no cambiar la contraseña
                            </small>
                        </div>
                    </div>

                    <div class="form-section">
                        <h4 class="section-title">
                            <i class="fas fa-globe"></i> Preferencias
                        </h4>
                        <div class="form-group">
                            <?= $this->Form->control('languaje', [
                                'label' => [
                                    'text' => '<i class="fas fa-language"></i> Idioma',
                                    'escape' => false
                                ],
                                'options' => [
                                    'es' => '🇪🇸 Español',
                                    'en' => '🇬🇧 English',
                                    'pt' => '🇧🇷 Português'
                                ],
                                'class' => 'form-select',
                                'value' => $user->languaje ?? 'es',
                                'required' => true
                            ]) ?>
                        </div>
                    </div>

                    <!-- Información del sistema (solo lectura) -->
                    <div class="form-section info-section">
                        <h4 class="section-title">
                            <i class="fas fa-info-circle"></i> Información del Sistema
                        </h4>
                        <div class="info-grid">
                            <div class="info-item">
                                <div class="info-label">
                                    <i class="fas fa-hashtag"></i> ID de Usuario
                                </div>
                                <div class="info-value">
                                    <span class="id-badge">#<?= $this->Number->format($user->id) ?></span>
                                </div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">
                                    <i class="far fa-calendar-alt"></i> Fecha de Creación
                                </div>
                                <div class="info-value">
                                    <i class="far fa-clock me-1"></i>
                                    <?= $user->created ? $user->created->format('d/m/Y H:i:s') : '—' ?>
                                </div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">
                                    <i class="fas fa-sync-alt"></i> Última Actualización
                                </div>
                                <div class="info-value">
                                    <i class="far fa-clock me-1"></i>
                                    <?= $user->modified ? $user->modified->format('d/m/Y H:i:s') : '—' ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </fieldset>

                <div class="form-actions">
                    <?= $this->Form->button(
                        '<i class="fas fa-save"></i> ' . __('Actualizar Usuario'),
                        ['class' => 'btn btn-primary', 'escape' => false]
                    ) ?>
                    <?= $this->Html->link(
                        '<i class="fas fa-times"></i> ' . __('Cancelar'),
                        ['action' => 'index'],
                        ['class' => 'btn btn-secondary', 'escape' => false]
                    ) ?>
                </div>
                <?= $this->Form->end() ?>
            </div>
        </div>
    </div>
</div>

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />

<style>
    /* Variables para modo claro */
    :root {
        --bg-primary: #f5f7fb;
        --bg-secondary: #ffffff;
        --text-primary: #2d3748;
        --text-secondary: #718096;
        --border-color: #e2e8f0;
        --card-bg: #ffffff;
        --sidebar-bg: #f8f9fa;
        --input-bg: #ffffff;
        --input-border: #e2e8f0;
        --shadow-sm: 0 1px 3px rgba(0,0,0,0.1);
        --shadow-md: 0 4px 6px rgba(0,0,0,0.07);
        --shadow-lg: 0 10px 25px rgba(0,0,0,0.1);
        --primary-color: #4361ee;
        --primary-dark: #3a56d4;
        --success-color: #28a745;
        --danger-color: #dc3545;
        --warning-color: #ffc107;
        --gradient-primary: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }

    /* Variables para modo noche */
    body.dark-mode {
        --bg-primary: #1a1a2e;
        --bg-secondary: #16213e;
        --text-primary: #e0e0e0;
        --text-secondary: #a0a0a0;
        --border-color: #2d2d44;
        --card-bg: #0f0f1a;
        --sidebar-bg: #0a0a14;
        --input-bg: #1a1a2e;
        --input-border: #2d2d44;
        --shadow-sm: 0 1px 3px rgba(0,0,0,0.3);
        --shadow-md: 0 4px 6px rgba(0,0,0,0.3);
        --shadow-lg: 0 10px 25px rgba(0,0,0,0.3);
        --primary-color: #5a7d9a;
    }

    /* Estilos generales */
    body {
        background-color: var(--bg-primary);
        color: var(--text-primary);
        transition: all 0.3s ease;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    }

    .form-container {
        max-width: 1400px;
        margin: 0 auto;
        padding: 20px;
        position: relative;
    }

    /* Switch modo noche */
    .theme-switch-wrapper {
        position: fixed;
        top: 20px;
        right: 20px;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        background: var(--card-bg);
        padding: 8px 12px;
        border-radius: 30px;
        box-shadow: var(--shadow-sm);
        z-index: 1000;
    }

    .theme-icon {
        font-size: 14px;
        color: var(--text-secondary);
    }

    .theme-switch {
        position: relative;
        display: inline-block;
        width: 50px;
        height: 24px;
    }

    .theme-switch input {
        opacity: 0;
        width: 0;
        height: 0;
    }

    .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: 0.4s;
        border-radius: 34px;
    }

    .slider:before {
        position: absolute;
        content: "";
        height: 18px;
        width: 18px;
        left: 3px;
        bottom: 3px;
        background-color: white;
        transition: 0.4s;
        border-radius: 50%;
    }

    input:checked + .slider {
        background-color: #2196f3;
    }

    input:checked + .slider:before {
        transform: translateX(26px);
    }

    /* Sidebar */
    .side-nav {
        background: var(--sidebar-bg);
        border-radius: 12px;
        padding: 20px;
        box-shadow: var(--shadow-sm);
        border: 1px solid var(--border-color);
    }

    .heading {
        color: var(--text-primary);
        font-size: 1.1rem;
        font-weight: 600;
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 2px solid var(--primary-color);
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .action-buttons {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .side-nav-item {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 10px 15px;
        border-radius: 8px;
        color: var(--text-primary);
        text-decoration: none;
        transition: all 0.2s ease;
        background: var(--card-bg);
        border: none;
        width: 100%;
        cursor: pointer;
        font-size: 14px;
    }

    .side-nav-item:hover {
        transform: translateX(5px);
        text-decoration: none;
    }

    .delete-btn:hover {
        background: var(--danger-color);
        color: white;
    }

    .list-btn:hover {
        background: var(--primary-color);
        color: white;
    }

    .view-btn:hover {
        background: var(--success-color);
        color: white;
    }

    /* Formulario principal */
    .users.form.content {
        background: var(--card-bg);
        border-radius: 12px;
        padding: 30px;
        box-shadow: var(--shadow-lg);
        border: 1px solid var(--border-color);
        animation: fadeIn 0.5s ease;
    }

    .form-header {
        display: flex;
        align-items: center;
        gap: 20px;
        margin-bottom: 30px;
        padding-bottom: 20px;
        border-bottom: 2px solid var(--border-color);
    }

    .form-icon {
        width: 60px;
        height: 60px;
        background: var(--gradient-primary);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 28px;
        color: white;
        box-shadow: var(--shadow-md);
    }

    .form-title-section h3 {
        font-size: 24px;
        font-weight: 600;
        margin: 0;
        color: var(--text-primary);
    }

    .form-subtitle {
        margin: 5px 0 0;
        color: var(--text-secondary);
        font-size: 14px;
    }

    .form-subtitle strong {
        color: var(--primary-color);
    }

    /* Secciones del formulario */
    .form-section {
        margin-bottom: 30px;
        padding: 20px;
        background: var(--bg-secondary);
        border-radius: 10px;
        border: 1px solid var(--border-color);
    }

    .section-title {
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 20px;
        color: var(--primary-color);
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .form-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 500;
        color: var(--text-primary);
        font-size: 14px;
    }

    .form-group label i {
        margin-right: 6px;
        color: var(--primary-color);
    }

    .form-control, .form-select {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid var(--input-border);
        border-radius: 8px;
        background: var(--input-bg);
        color: var(--text-primary);
        transition: all 0.2s ease;
        font-size: 14px;
    }

    .form-control:focus, .form-select:focus {
        outline: none;
        border-color: var(--primary-color);
        box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.1);
    }

    /* Sección de información del sistema */
    .info-section {
        background: var(--bg-secondary);
    }

    .info-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
    }

    .info-item {
        display: flex;
        flex-direction: column;
        gap: 8px;
    }

    .info-label {
        font-size: 12px;
        text-transform: uppercase;
        font-weight: 600;
        color: var(--text-secondary);
        letter-spacing: 0.5px;
        display: flex;
        align-items: center;
        gap: 6px;
    }

    .info-value {
        font-size: 14px;
        font-weight: 500;
        color: var(--text-primary);
    }

    .id-badge {
        display: inline-block;
        padding: 4px 12px;
        background: var(--primary-color);
        color: white;
        border-radius: 6px;
        font-family: monospace;
        font-size: 14px;
    }

    /* Medidor de contraseña */
    .password-strength {
        margin-top: 8px;
        height: 4px;
        background: var(--border-color);
        border-radius: 2px;
        overflow: hidden;
        position: relative;
    }

    .strength-bar {
        height: 100%;
        width: 0;
        transition: all 0.3s ease;
        border-radius: 2px;
    }

    .strength-text {
        display: inline-block;
        margin-top: 5px;
        font-size: 12px;
        color: var(--text-secondary);
    }

    .strength-weak .strength-bar {
        width: 33%;
        background: #dc3545;
    }

    .strength-medium .strength-bar {
        width: 66%;
        background: #ffc107;
    }

    .strength-strong .strength-bar {
        width: 100%;
        background: #28a745;
    }

    /* Form text */
    .form-text {
        display: block;
        margin-top: 5px;
        font-size: 12px;
        color: var(--text-secondary);
    }

    .form-text i {
        margin-right: 4px;
    }

    /* Botones de acción */
    .form-actions {
        display: flex;
        gap: 15px;
        justify-content: flex-end;
        padding-top: 20px;
        border-top: 1px solid var(--border-color);
        margin-top: 20px;
    }

    .btn {
        padding: 10px 24px;
        border-radius: 8px;
        text-decoration: none;
        transition: all 0.2s ease;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        font-weight: 500;
        border: none;
        cursor: pointer;
        font-size: 14px;
    }

    .btn-primary {
        background: var(--gradient-primary);
        color: white;
    }

    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
    }

    .btn-secondary {
        background: var(--bg-secondary);
        color: var(--text-primary);
        border: 1px solid var(--border-color);
    }

    .btn-secondary:hover {
        background: var(--border-color);
        transform: translateY(-2px);
    }

    /* Animaciones */
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    /* Responsive */
    @media (max-width: 768px) {
        .form-container {
            padding: 10px;
        }

        .theme-switch-wrapper {
            position: relative;
            top: 0;
            right: 0;
            justify-content: flex-end;
            margin-bottom: 20px;
        }

        .row {
            flex-direction: column;
        }

        .column {
            width: 100% !important;
        }

        .form-header {
            flex-direction: column;
            text-align: center;
        }

        .form-grid, .info-grid {
            grid-template-columns: 1fr;
        }

        .form-actions {
            flex-direction: column;
        }

        .btn {
            justify-content: center;
        }
    }
</style>

<script>
    // Modo noche con localStorage
    document.addEventListener('DOMContentLoaded', function() {
        const toggleSwitch = document.getElementById('theme-toggle');
        
        // Verificar preferencia guardada
        const currentTheme = localStorage.getItem('theme');
        
        if (currentTheme) {
            document.body.classList.add(currentTheme);
            if (currentTheme === 'dark-mode') {
                toggleSwitch.checked = true;
            }
        }
        
        // Escuchar cambio de tema
        toggleSwitch.addEventListener('change', function(e) {
            if (e.target.checked) {
                document.body.classList.add('dark-mode');
                localStorage.setItem('theme', 'dark-mode');
            } else {
                document.body.classList.remove('dark-mode');
                localStorage.setItem('theme', 'light-mode');
            }
        });

        // Medidor de fortaleza de contraseña
        const passwordInput = document.querySelector('input[name="password"]');
        const strengthDiv = document.getElementById('password-strength');
        
        if (passwordInput) {
            passwordInput.addEventListener('input', function() {
                const password = this.value;
                const strength = checkPasswordStrength(password);
                
                // Remover clases anteriores
                strengthDiv.classList.remove('strength-weak', 'strength-medium', 'strength-strong');
                
                if (password.length === 0) {
                    strengthDiv.querySelector('.strength-text').textContent = '';
                    return;
                }
                
                if (strength === 'weak') {
                    strengthDiv.classList.add('strength-weak');
                    strengthDiv.querySelector('.strength-text').textContent = '🔴 Contraseña débil';
                } else if (strength === 'medium') {
                    strengthDiv.classList.add('strength-medium');
                    strengthDiv.querySelector('.strength-text').textContent = '🟡 Contraseña media';
                } else {
                    strengthDiv.classList.add('strength-strong');
                    strengthDiv.querySelector('.strength-text').textContent = '🟢 Contraseña fuerte';
                }
            });
        }
        
        function checkPasswordStrength(password) {
            let strength = 0;
            
            if (password.length >= 6) strength++;
            if (password.length >= 8) strength++;
            if (password.match(/[a-z]+/)) strength++;
            if (password.match(/[A-Z]+/)) strength++;
            if (password.match(/[0-9]+/)) strength++;
            if (password.match(/[$@#&!]+/)) strength++;
            
            if (strength <= 2) return 'weak';
            if (strength <= 4) return 'medium';
            return 'strong';
        }
    });
</script>